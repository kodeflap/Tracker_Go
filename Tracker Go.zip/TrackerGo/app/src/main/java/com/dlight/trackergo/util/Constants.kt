package com.dlight.trackergo.util

object Constants {
    const val RUNNING_DATABASE_NAME = "tracker_db"

    const val REQUEST_CODE_LOCATION_PERMISSION = 0
}