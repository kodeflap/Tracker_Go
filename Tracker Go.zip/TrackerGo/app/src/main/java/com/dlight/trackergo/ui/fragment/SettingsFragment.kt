package com.dlight.trackergo.ui.fragment

import androidx.fragment.app.Fragment
import com.dlight.trackergo.R

class SettingsFragment : Fragment(R.layout.fragment_settings) {
}